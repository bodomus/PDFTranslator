# PDFTranslate — Ticket Index

Recommended implementation order:

1. `PDFTR-1-project-bootstrap.md`
2. `PDFTR-2-pdf-inspection-and-extraction.md`
3. `PDFTR-3-local-translation-engine.md`
4. `PDFTR-4-render-translated-pdf.md`
5. `PDFTR-5-end-to-end-cli.md`
6. `PDFTR-6-ocr-for-scanned-pdfs.md`
7. `PDFTR-7-folder-batch-processing.md`

The first usable text-PDF MVP is reached after PDFTR-5.
Scanned PDF support is added by PDFTR-6.
Folder processing is added by PDFTR-7.
