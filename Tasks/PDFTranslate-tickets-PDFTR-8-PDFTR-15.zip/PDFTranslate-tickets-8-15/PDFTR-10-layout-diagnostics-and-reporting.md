# PDFTR-10 — Layout diagnostics and translation report

## Summary

Add structured run diagnostics and visual layout debugging for successful and failed translations.

## Dependencies

Requires completion of PDFTR-1 through PDFTR-9 unless this ticket explicitly refers to findings that can be gathered in parallel.

## Required workflow

Treat this as a Level 2 task under `.codex/PRE_TICKET_WORKFLOW.md`.

Before implementation:

1. inspect the current repository, Git state, `AGENTS.md`, workflow instructions, tests, CLI, schemas and relevant pipeline stages;
2. run confirmed Graphify and CRG preflight when available;
3. validate graph findings in Python source;
4. create `investigation.md` and `implementation-plan.md`;
5. preserve unrelated user changes;
6. implement the smallest coherent solution.

## Goal

Make extraction, translation, OCR, fitting, rendering, cache and validation problems diagnosable without manually reading the entire PDF.

## Scope and requirements

Generate where requested:

```text
translation-report.json
translation-report.html
debug-layout.pdf
```

Report summary metrics: pages by type, blocks extracted/translated/skipped, cache hits/misses, OCR pages, font substitutions/reductions, expanded and overflow blocks, redaction/render/validation warnings, durations, input/output sizes, and peak RAM/VRAM when measurable.

Add page-level and block-level diagnostics with stable IDs, bounding boxes, font sizes, fitting attempts, segmentation count, cache status, warning codes and final state.

Do not include source or translated text by default. Add explicit opt-in debug inclusion.

Define centralized stable codes such as `READING_ORDER_AMBIGUOUS`, `TRANSLATION_TOKEN_MISMATCH`, `FONT_REDUCED`, `BLOCK_OVERFLOW`, `OCR_LOW_TEXT_GAIN`, and `OUTPUT_VALIDATION_FAILED`.

The offline HTML report must use no external assets. `debug-layout.pdf` must mark source/final rectangles, overflow, expansion, skipped blocks, OCR pages and IDs without altering the normal output.

Add CLI options such as `--report`, `--report-format`, `--report-dir`, `--debug-layout`, and `--include-report-text`. Machine-readable output must contain no Rich markup.

## Tests and validation

Cover successful and failed reports, overflow, cache hit, OCR status, warning-code stability, offline HTML, debug PDF, privacy defaults, opt-in text and Cyrillic content.

Normal unit tests and CI must not download translation models, require CUDA, or require OCR system tools. Use generated fixtures, fakes and mocks. Real-model, GPU, OCR and real-PDF tests must be explicit opt-in checks.

## Acceptance criteria

- [ ] JSON reports exist for success and failure when possible.
- [ ] Offline HTML report works.
- [ ] Stable warning/error codes exist.
- [ ] Page/block diagnostics are available.
- [ ] Debug PDF marks problem blocks.
- [ ] Text is excluded by default.
- [ ] Cache/OCR/fitting/overflow/validation data is included.
- [ ] Existing CLI remains compatible.
- [ ] All checks pass.

## Non-goals

No report editor, hosted dashboard, telemetry upload, automatic issue submission, or embedded full PDFs.

## Documentation

Update the applicable files:

- `README.md`;
- `CHANGELOG.md`;
- CLI `--help`;
- configuration/schema documentation;
- troubleshooting or Windows instructions where relevant.

## Required completion report

Provide:

1. repository state before changes;
2. workflow level and Graphify/CRG status;
3. investigation findings and root cause or capability gap;
4. files and symbols changed;
5. commands actually executed;
6. focused and full test results;
7. Ruff, mypy and script results;
8. real-model, CUDA, OCR and real-PDF validation status;
9. remaining risks and deferred work.
