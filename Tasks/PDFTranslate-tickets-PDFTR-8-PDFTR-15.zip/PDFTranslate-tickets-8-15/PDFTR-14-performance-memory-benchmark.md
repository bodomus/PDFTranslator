# PDFTR-14 — Performance, memory, cache and CUDA benchmark

## Summary

Measure and stabilize speed, RAM, VRAM, cache behavior and CUDA fallback.

## Dependencies

Requires completion of PDFTR-1 through PDFTR-13 unless this ticket explicitly refers to findings that can be gathered in parallel.

## Required workflow

Treat this as a Level 2 task under `.codex/PRE_TICKET_WORKFLOW.md`.

Before implementation:

1. inspect the current repository, Git state, `AGENTS.md`, workflow instructions, tests, CLI, schemas and relevant pipeline stages;
2. run confirmed Graphify and CRG preflight when available;
3. validate graph findings in Python source;
4. create `investigation.md` and `implementation-plan.md`;
5. preserve unrelated user changes;
6. implement the smallest coherent solution.

## Goal

Produce reproducible evidence and safe defaults for CPU-only systems and an RTX 4080 16 GB class workstation.

## Scope and requirements

Benchmark where available: 10, 100 and 300-page text PDFs, image-heavy PDF, OCR-required PDF, cold/warm cache, fresh/resumed process, CPU, CUDA and folder batch.

Measure total and stage durations, model load, tokenization, translation, render, OCR, validation, pages/minute, blocks/tokens per second, input/output size, peak RAM/VRAM, cache ratio, model load count, batch size and OOM/fallback events.

Implement an opt-in runner such as:

```bash
pdftranslate benchmark-performance benchmark-plan.json
```

Support warm-up, repetitions, median and percentiles, environment/dependency/GPU metadata, commit/version, JSON and Markdown, and no forced network access.

Validate `auto`, `cpu`, and `cuda`, unavailable CUDA behavior, bounded OOM recovery, cleanup after failed batches and CPU continuation policy. Never use infinite retry.

Based on evidence, define safe defaults for device, batch size, token budget, OOM fallback, concurrency and cache. CPU must remain supported.

Provide optional regression comparison, but do not make hardware-sensitive benchmarks mandatory in normal CI.

## Tests and validation

Unit-test plan parsing, metrics, median/percentiles, metadata, fake runner, thresholds, CUDA unavailable and OOM state machine. Real benchmarks are opt-in.

Normal unit tests and CI must not download translation models, require CUDA, or require OCR system tools. Use generated fixtures, fakes and mocks. Real-model, GPU, OCR and real-PDF tests must be explicit opt-in checks.

## Acceptance criteria

- [ ] Reproducible runner exists.
- [ ] JSON/Markdown reports exist.
- [ ] Cold/warm cache and model load are distinct.
- [ ] CPU is measured.
- [ ] CUDA is measured when available.
- [ ] Peak RAM/VRAM is reported when measurable.
- [ ] OOM fallback is bounded and tested.
- [ ] Safe defaults are evidence-based.
- [ ] Normal CI excludes performance runs.
- [ ] All checks pass.

## Non-goals

No distributed/multi-GPU/cloud benchmarking, overclocking, claims for untested hardware, or unsafe default concurrency.

## Documentation

Update the applicable files:

- `README.md`;
- `CHANGELOG.md`;
- CLI `--help`;
- configuration/schema documentation;
- troubleshooting or Windows instructions where relevant.

## Required completion report

Provide:

1. repository state before changes;
2. workflow level and Graphify/CRG status;
3. investigation findings and root cause or capability gap;
4. files and symbols changed;
5. commands actually executed;
6. focused and full test results;
7. Ruff, mypy and script results;
8. real-model, CUDA, OCR and real-PDF validation status;
9. remaining risks and deferred work.
