# PDFTR-15 — Windows release packaging and portable distribution

## Summary

Create a reproducible portable Windows release for PDFTranslate.

## Dependencies

Requires completion of PDFTR-1 through PDFTR-14 unless this ticket explicitly refers to findings that can be gathered in parallel.

## Required workflow

Treat this as a Level 2 task under `.codex/PRE_TICKET_WORKFLOW.md`.

Before implementation:

1. inspect the current repository, Git state, `AGENTS.md`, workflow instructions, tests, CLI, schemas and relevant pipeline stages;
2. run confirmed Graphify and CRG preflight when available;
3. validate graph findings in Python source;
4. create `investigation.md` and `implementation-plan.md`;
5. preserve unrelated user changes;
6. implement the smallest coherent solution.

## Goal

Produce a tested `PDFTranslate-vX.Y.Z-win-x64.zip` usable without a developer checkout, while keeping models and OCR tools external by default.

## Scope and requirements

First evaluate packaging constraints for Python, PyMuPDF, Torch, Transformers, SentencePiece, Typer/Rich and OCR subprocesses. Choose the most reliable outcome: executable, embedded Python distribution, or portable application folder. Do not force a fragile single-file executable.

The archive must include launcher/runtime, README, LICENSE, `THIRD_PARTY_NOTICES.md`, VERSION, config and required runtime files. Exclude models, caches, tests, source corpus, logs, `.git` and development tools.

Support first-use model download, existing cache, offline mode and configurable cache path. `doctor` must report model and OCR dependency status. OCRmyPDF/Tesseract/Ghostscript may remain external; do not redistribute them without license review.

Use one authoritative semantic version. Include commit, build date, target platform and runtime metadata. `--version` must match.

Add strict build script:

```powershell
.\scripts\build-release.ps1 -Version 0.2.0
```

It must use locked dependencies, clean staging, run packaged smoke tests, create ZIP, SHA256 and manifest, reject user-specific paths and fail non-zero.

Validate in a clean Windows environment where practical: version, doctor, help, dry run, small text-PDF translation, model download/cache/offline behavior, spaces/Cyrillic paths, source preservation, output reopening, OCR diagnostics and removal by deleting the folder.

Add a least-privilege GitHub Actions release workflow for tag/manual dispatch that builds Windows artifact and checksum without CUDA or model download.

## Tests and validation

Test version consistency, manifest, archive contents, prohibited-file absence, checksum, packaged CLI, missing model/OCR, Cyrillic paths and build failure propagation.

Normal unit tests and CI must not download translation models, require CUDA, or require OCR system tools. Use generated fixtures, fakes and mocks. Real-model, GPU, OCR and real-PDF tests must be explicit opt-in checks.

## Acceptance criteria

- [ ] Reproducible Windows build script exists.
- [ ] Portable ZIP is produced.
- [ ] Version metadata is consistent.
- [ ] SHA256 and manifest are generated.
- [ ] Models/caches/logs/tests/corpus are absent.
- [ ] Packaged CLI passes smoke tests.
- [ ] Text-PDF translation works from package.
- [ ] OCR dependencies are diagnosed.
- [ ] GitHub Actions builds without CUDA/model download.
- [ ] Third-party notices exist.
- [ ] All checks pass.

## Non-goals

No MSI, Store distribution, auto-updater, bundled model weights, bundled OCR tools without license review, or GUI.

## Documentation

Update the applicable files:

- `README.md`;
- `CHANGELOG.md`;
- CLI `--help`;
- configuration/schema documentation;
- troubleshooting or Windows instructions where relevant.

## Required completion report

Provide:

1. repository state before changes;
2. workflow level and Graphify/CRG status;
3. investigation findings and root cause or capability gap;
4. files and symbols changed;
5. commands actually executed;
6. focused and full test results;
7. Ruff, mypy and script results;
8. real-model, CUDA, OCR and real-PDF validation status;
9. remaining risks and deferred work.
