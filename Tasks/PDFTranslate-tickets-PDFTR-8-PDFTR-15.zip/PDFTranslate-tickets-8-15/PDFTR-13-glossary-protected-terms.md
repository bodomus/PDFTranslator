# PDFTR-13 — Glossary and protected terminology

## Summary

Add backend-independent user control over required translations and terms that must remain unchanged.

## Dependencies

Requires completion of PDFTR-1 through PDFTR-12 unless this ticket explicitly refers to findings that can be gathered in parallel.

## Required workflow

Treat this as a Level 2 task under `.codex/PRE_TICKET_WORKFLOW.md`.

Before implementation:

1. inspect the current repository, Git state, `AGENTS.md`, workflow instructions, tests, CLI, schemas and relevant pipeline stages;
2. run confirmed Graphify and CRG preflight when available;
3. validate graph findings in Python source;
4. create `investigation.md` and `implementation-plan.md`;
5. preserve unrelated user changes;
6. implement the smallest coherent solution.

## Goal

Support technical terminology consistently in single-file, batch, benchmark, resume and cache workflows.

## Scope and requirements

Add a versioned UTF-8 glossary schema and CLI support:

```bash
pdftranslate manual.pdf --glossary glossary.json
```

Support modes:

- `required`: specified Russian form must appear;
- `preferred`: use when safe and report unresolved cases;
- `preserve`: source term must remain unchanged.

Support simple per-entry options for case sensitivity, whole-word matching, phrase matching, enabled state and notes. Keep version 1 deterministic and do not attempt unrestricted Russian morphology.

Use a backend-independent placeholder/protection and validation strategy. Placeholders must never leak. Resolve overlaps deterministically, generally preferring longer phrases, and remain compatible with URL/path/code protection.

Validate duplicates, conflicts, empty terms, invalid modes/options, encoding and schema version.

Include a stable glossary fingerprint in translation-cache keys and resume identity. Changing the glossary must invalidate incompatible results. Load once per batch and report application/violations through PDFTR-10.

## Tests and validation

Cover required/preferred/preserve, phrase precedence, overlaps, case modes, whole word, Cyrillic output, placeholder leakage, cache invalidation, malformed/conflicting files, batch reuse and benchmark integration.

Normal unit tests and CI must not download translation models, require CUDA, or require OCR system tools. Use generated fixtures, fakes and mocks. Real-model, GPU, OCR and real-PDF tests must be explicit opt-in checks.

## Acceptance criteria

- [ ] `--glossary` works end to end.
- [ ] Schema is versioned.
- [ ] Required/preferred/preserve modes exist.
- [ ] Placeholders cannot leak.
- [ ] Overlap handling is deterministic.
- [ ] Glossary fingerprint affects cache/resume.
- [ ] Violations are reported.
- [ ] Batch loads glossary once.
- [ ] Benchmark supports glossary.
- [ ] All checks pass.

## Non-goals

No graphical editor, automatic glossary extraction, cloud terminology service, full morphology engine, or additional language pairs.

## Documentation

Update the applicable files:

- `README.md`;
- `CHANGELOG.md`;
- CLI `--help`;
- configuration/schema documentation;
- troubleshooting or Windows instructions where relevant.

## Required completion report

Provide:

1. repository state before changes;
2. workflow level and Graphify/CRG status;
3. investigation findings and root cause or capability gap;
4. files and symbols changed;
5. commands actually executed;
6. focused and full test results;
7. Ruff, mypy and script results;
8. real-model, CUDA, OCR and real-PDF validation status;
9. remaining risks and deferred work.
