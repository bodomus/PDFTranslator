# PDFTranslate — PDFTR-8 through PDFTR-15

## Recommended order

1. PDFTR-8 — Real PDF end-to-end validation
2. PDFTR-9 — Translation quality benchmark
3. PDFTR-10 — Layout diagnostics and reporting
4. PDFTR-11 — Paragraph reconstruction
5. PDFTR-12 — Repeated headers and footers
6. PDFTR-13 — Glossary and protected terms
7. PDFTR-14 — Performance and memory benchmark
8. PDFTR-15 — Windows release packaging

## Dependency chain

```text
PDFTR-8
  ├─ PDFTR-9
  └─ PDFTR-10
       └─ PDFTR-11
            └─ PDFTR-12
                 └─ PDFTR-13
                      └─ PDFTR-14
                           └─ PDFTR-15
```

PDFTR-9 and PDFTR-10 can begin from PDFTR-8 findings. All tickets must follow `.codex/PRE_TICKET_WORKFLOW.md`. Level 2 tickets require `investigation.md`, `implementation-plan.md`, and an implementation report that distinguishes actual validation from unavailable model/CUDA/OCR/real-PDF checks.
